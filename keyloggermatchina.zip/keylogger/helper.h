#ifndef HELPER_H
#define HELPER_H

#include <ctime>
#include <string>
#include <sstream>
#include <fstream>

namespace helper {

    // Template function to convert any type to a string using std::ostringstream
    template <class T>
    std::string ToString(const T& e) {
        std::ostringstream s;
        s << e;
        return s.str();
    }

    struct DateTime {
        int D, m, y, H, M, S;

        // Default constructor that initializes the DateTime to the current time
        DateTime() {
            std::time_t ms = std::time(nullptr);
            struct tm info;
            localtime_s(&info, &ms);  // Thread-safe version of localtime

            D = info.tm_mday;
            m = info.tm_mon + 1;
            y = 1900 + info.tm_year;
            H = info.tm_hour;
            M = info.tm_min;
            S = info.tm_sec;
        }

        // Parameterized constructors
        DateTime(int D, int m, int y, int H = 0, int M = 0, int S = 0)
            : D(D), m(m), y(y), H(H), M(M), S(S) {}

        // Static method to get the current DateTime
        static DateTime now() {
            return DateTime();
        }

        // Method to get the date as a string in "DD.MM.YYYY" format
        std::string GetDateString() const {
            return (D < 10 ? "0" : "") + ToString(D) +
                   (m < 10 ? ".0" : ".") + ToString(m) +
                   "." + ToString(y);
        }

        // Method to get the time as a string in "HH:MM:SS" format
        std::string GetTimeString(const std::string& sep = ":") const {
            return (H < 10 ? "0" : "") + ToString(H) + sep +
                   (M < 10 ? "0" : "") + ToString(M) + sep +
                   (S < 10 ? "0" : "") + ToString(S);
        }

        // Method to get the full date-time string in "DD.MM.YYYY HH:MM:SS" format
        std::string GetDateTimeString(const std::string& sep = ":") const {
            return GetDateString() + " " + GetTimeString(sep);
        }
    };

    // Function to write logs into "applog.txt"
    void writeAppLog(const std::string& s) {
        std::ofstream file("applog.txt", std::ios::app);
        if (file.is_open()) {
            file << "{" << DateTime::now().GetDateTimeString() << "}" << "\n"
                 << s << std::endl << "\n";
            file.close();
        }
    }

}  // namespace helper

#endif  // HELPER_H
