#ifndef TIMER_H
#define TIMER_H

#include <thread>
#include <chrono>
#include <functional>
#include <atomic>

class Timer {
    std::thread Thread;  // Thread to run the timer
    std::atomic<bool> Alive{false};  // Atomic flag to ensure thread-safe access
    long CallNumber = -1L;  // Total number of times the function will be called
    std::atomic<long> repeat_count{-1L};  // Tracks how many repetitions are left
    std::chrono::milliseconds interval{0};  // Interval between function calls
    std::function<void()> funct = nullptr;  // Function to be executed

    // Sleep for the interval and execute the function
    void SleepAndRun() {
        std::this_thread::sleep_for(interval);
        if (Alive && funct) {
            funct();  // Execute the assigned function if still alive
        }
    }

    // Main thread function to control the timer’s execution
    void ThreadFunc() {
        if (CallNumber == infinite) {
            while (Alive) {
                SleepAndRun();
            }
        } else {
            while (repeat_count > 0 && Alive) {
                SleepAndRun();
                --repeat_count;  // Decrement the repeat count after each run
            }
        }
    }

public:
    static const long infinite = -1L;

    // Default constructor
    Timer() = default;

    // Constructor to assign a function to the timer
    Timer(const std::function<void()>& f) : funct(f) {}

    // Constructor with function, interval, and repeat count
    Timer(const std::function<void()>& f, unsigned long i, long repeat = Timer::infinite)
        : funct(f), interval(std::chrono::milliseconds(i)), CallNumber(repeat) {}

    // Start the timer, with an option to run asynchronously
    void Start(bool Async = true) {
        if (IsAlive()) return;  // Prevent starting if already running

        Alive = true;
        repeat_count = CallNumber;

        if (Async) {
            Thread = std::thread(&Timer::ThreadFunc, this);  // Launch in a separate thread
        } else {
            ThreadFunc();  // Run directly
        }
    }

    // Stop the timer and join the thread
    void Stop() {
        Alive = false;  // Set the flag to stop the timer
        if (Thread.joinable()) {
            Thread.join();  // Ensure the thread is properly joined
        }
    }

    // Assign a new function to the timer
    void SetFunction(const std::function<void()>& f) {
        if (IsAlive()) return;  // Do not change the function while running
        funct = f;
    }

    // Check if the timer is currently running
    bool IsAlive() const noexcept { return Alive; }

    // Set the number of times the function should be executed
    void SetRepeatCount(long r) {
        if (IsAlive()) return;  // Do not modify while running
        CallNumber = r;
    }

    // Get the remaining number of repetitions
    long GetLeftCount() const noexcept { return repeat_count; }

    // Get the total number of repetitions
    long RepeatCount() const noexcept { return CallNumber; }

    // Set the interval between function executions (in milliseconds)
    void SetInterval(unsigned long i) {
        if (IsAlive()) return;  // Do not modify the interval while running
        interval = std::chrono::milliseconds(i);
    }

    // Get the current interval (in milliseconds)
    unsigned long Interval() const noexcept { return interval.count(); }

    // Get the function assigned to the timer
    const std::function<void()>& Function() const noexcept { return funct; }
};

#endif  // TIMER_H
