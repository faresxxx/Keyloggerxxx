#ifndef KEYCONSTANTS_H
#define KEYCONSTANTS_H

#include <map>
#include <string>

// A small key-value structure to store virtual key info
class KeyPair {
public:
    KeyPair(const std::string& vk = "", const std::string& name = "")
        : VKName(vk), Name(name) {}

    std::string VKName;
    std::string Name;
};


class Keys {
public:
    // Inline static member initialization (C++17 feature)
    inline static const std::map<int, KeyPair> KEYS = {
        {0xC1, {"[VK_ABNT_C1]", "[Abnt C1]"}},
        {0xC2, {"[VK_ABNT_C2]", "[Abnt C2]"}},
        {0x6B, {"[VK_ADD]", "[Numpad +]"}},
        {0xF6, {"[VK_ATTN]", "[Attn]"}},
        {0x08, {"[VK_BACK]", "[Backspace]"}},
        {0x03, {"[VK_CANCEL]", "[Break]"}},
        {0x0C, {"[VK_CLEAR]", "[Clear]"}},
        {0xF7, {"[VK_CRSEL]", "[Cr Sel]"}},
        {0x6E, {"[VK_DECIMAL]", "[Numpad .]"}},
        {0x6F, {"[VK_DIVIDE]", "[Numpad /]"}},
        {0xF9, {"[VK_EREOF]", "[Er Eof]"}},
        {0x1B, {"[VK_ESCAPE]", "[Esc]"}},
        {0x2B, {"[VK_EXECUTE]", "[Execute]"}},
        {0xF8, {"[VK_EXSEL]", "[Ex Sel]"}},
        {0xE6, {"[VK_ICO_CLEAR]", "[IcoClr]"}},
        {0xE3, {"[VK_ICO_HELP]", "[IcoHlp]"}},
        {0x30, {"[VK_KEY_0]", "[D0]"}},
        {0x31, {"[VK_KEY_1]", "[D1]"}},
        {0x32, {"[VK_KEY_2]", "[D2]"}},
        {0x33, {"[VK_KEY_3]", "[D3]"}},
        {0x34, {"[VK_KEY_4]", "[D4]"}},
        {0x35, {"[VK_KEY_5]", "[D5]"}},
        {0x36, {"[VK_KEY_6]", "[D6]"}},
        {0x37, {"[VK_KEY_7]", "[D7]"}},
        {0x38, {"[VK_KEY_8]", "[D8]"}},
        {0x39, {"[VK_KEY_9]", "[D9]"}},
        {0x41, {"[VK_KEY_A]", "[A]"}},
        {0x42, {"[VK_KEY_B]", "[B]"}},
        {0x43, {"[VK_KEY_C]", "[C]"}},
        {0x44, {"[VK_KEY_D]", "[D]"}},
        {0x45, {"[VK_KEY_E]", "[E]"}},
        {0x46, {"[VK_KEY_F]", "[F]"}},
        {0x47, {"[VK_KEY_G]", "[G]"}},
        {0x48, {"[VK_KEY_H]", "[H]"}},
        {0x49, {"[VK_KEY_I]", "[I]"}},
        {0x4A, {"[VK_KEY_J]", "[J]"}},
        {0x4B, {"[VK_KEY_K]", "[K]"}},
        {0x4C, {"[VK_KEY_L]", "[L]"}},
        {0x4D, {"[VK_KEY_M]", "[M]"}},
        {0x4E, {"[VK_KEY_N]", "[N]"}},
        {0x4F, {"[VK_KEY_O]", "[O]"}},
        {0x50, {"[VK_KEY_P]", "[P]"}},
        {0x51, {"[VK_KEY_Q]", "[Q]"}},
        {0x52, {"[VK_KEY_R]", "[R]"}},
        {0x53, {"[VK_KEY_S]", "[S]"}},
        {0x54, {"[VK_KEY_T]", "[T]"}},
        {0x55, {"[VK_KEY_U]", "[U]"}},
        {0x56, {"[VK_KEY_V]", "[V]"}},
        {0x57, {"[VK_KEY_W]", "[W]"}},
        {0x58, {"[VK_KEY_X]", "[X]"}},
        {0x59, {"[VK_KEY_Y]", "[Y]"}},
        {0x5A, {"[VK_KEY_Z]", "[Z]"}},
        {0x6A, {"[VK_MULTIPLY]", "[Numpad *]"}},
        {0xFC, {"[VK_NONAME]", "[NoName]"}},
        {0x60, {"[VK_NUMPAD0]", "[N0]"}},
        {0x61, {"[VK_NUMPAD1]", "[N1]"}},
        {0x62, {"[VK_NUMPAD2]", "[N2]"}},
        {0x63, {"[VK_NUMPAD3]", "[N3]"}},
        {0x64, {"[VK_NUMPAD4]", "[N4]"}},
        {0x65, {"[VK_NUMPAD5]", "[N5]"}},
        {0x66, {"[VK_NUMPAD6]", "[N6]"}},
        {0x67, {"[VK_NUMPAD7]", "[N7]"}},
        {0x68, {"[VK_NUMPAD8]", "[N8]"}},
        {0x69, {"[VK_NUMPAD9]", "[N9]"}},
        {0xBA, {"[VK_OEM_1]", "[OEM_1 (: ;)]"}},
        {0xE2, {"[VK_OEM_102]", "[OEM_102 (> <)]"}},
        {0xBF, {"[VK_OEM_2]", "[OEM_2 (? /)]"}},
        {0xC0, {"[VK_OEM_3]", "[OEM_3 (~ `)]"}},
        {0xDB, {"[VK_OEM_4]", "[OEM_4 ({ [)]"}},
        {0xDC, {"[VK_OEM_5]", "[OEM_5 (| \\)]"}},
        {0xDD, {"[VK_OEM_6]", "[OEM_6 (} ])]"}},
        {0xDE, {"[VK_OEM_7]", "[OEM_7 (\" ')]"}},
        {0xDF, {"[VK_OEM_8]", "[OEM_8 (§ !)]"}},
        {0xF0, {"[VK_OEM_ATTN]", "[Oem Attn]"}},
        {0xF3, {"[VK_OEM_AUTO]", "[Auto]"}},
        {0xF2, {"[VK_OEM_COPY]", "[Copy]"}},
        {0x0D, {"[VK_RETURN]", "[Enter]"}},
        {0x50, {"[VK_LEFT]", "[Left]"}},
        {0x28, {"[VK_DOWN]", "[Down]"}},
        {0x73, {"[VK_F1]", "[F1]"}},
        {0x72, {"[VK_F2]", "[F2]"}},
        {0x71, {"[VK_F3]", "[F3]"}},
        {0x70, {"[VK_F4]", "[F4]"}},
        {0x75, {"[VK_TAB]", "[Tab]"}},
    };
};

#endif // KEYCONSTANTS_H

