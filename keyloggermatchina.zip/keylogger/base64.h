#ifndef BASE64_H
#define BASE64_H

#include <string>
#include <vector>
#include <stdexcept>

namespace Base64 {

    const std::string SALT1 = "LM:TB:BB";
    const std::string SALT2 = "_/:/_77";
    const std::string SALT3 = "line=wowC++";
    const std::string BASE64_CODES = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";

    // Base64 encoding function
    std::string base64_encode(const std::string& s) {
        std::string ret;
        int val = 0, bits = -6;
        const unsigned int b63 = 0x3F;

        for (const char& c : s) {
            val = (val << 8) + static_cast<unsigned char>(c);
            bits += 8;

            while (bits >= 0) {
                ret.push_back(BASE64_CODES[(val >> bits) & b63]);
                bits -= 6;
            }
        }

        if (bits > -6) {
            ret.push_back(BASE64_CODES[((val << 8) >> (bits + 8)) & b63]);
        }

        while (ret.size() % 4) {
            ret.push_back('=');
        }

        return ret;
    }

    // Base64 decoding function
    std::string base64_decode(const std::string& s) {
        if (s.size() % 4 != 0) {
            throw std::invalid_argument("Invalid Base64 input length.");
        }

        std::string ret;
        std::vector<int> T(256, -1);
        for (int i = 0; i < 64; ++i) {
            T[static_cast<unsigned char>(BASE64_CODES[i])] = i;
        }

        int val = 0, bits = -8;
        for (const char& c : s) {
            if (T[static_cast<unsigned char>(c)] == -1) {
                throw std::invalid_argument("Invalid Base64 character.");
            }
            val = (val << 6) + T[static_cast<unsigned char>(c)];
            bits += 6;

            if (bits >= 0) {
                ret.push_back(static_cast<char>((val >> bits) & 0xFF));
                bits -= 8;
            }
        }

        return ret;
    }

    // Encryption function
    std::string EncryptB64(const std::string& s) {
        std::string modified = SALT1 + s + SALT2 + SALT3;
        modified = base64_encode(modified);
        modified = SALT2 + modified + SALT1;
        modified = base64_encode(modified);
        modified = SALT3 + SALT2 + base64_encode(modified);
        return modified;
    }

    // Decryption function
    std::string DecryptB64(const std::string& encrypted) {
        std::string modified = base64_decode(encrypted);

        if (modified.size() < SALT3.size()) {
            throw std::runtime_error("Decryption failed: invalid input.");
        }
        modified.erase(0, SALT3.size());

        if (modified.size() < SALT2.size()) {
            throw std::runtime_error("Decryption failed: invalid input.");
        }
        modified.erase(modified.size() - SALT2.size());

        modified = base64_decode(modified);

        if (modified.size() < SALT2.size()) {
            throw std::runtime_error("Decryption failed: invalid input.");
        }
        modified.erase(0, SALT2.size());

        if (modified.size() < SALT1.size()) {
            throw std::runtime_error("Decryption failed: invalid input.");
        }
        modified.erase(modified.size() - SALT1.size());

        modified = base64_decode(modified);

        if (modified.size() < (SALT1.size() + SALT2.size() + SALT3.size())) {
            throw std::runtime_error("Decryption failed: invalid input.");
        }
        modified.erase(0, SALT1.size());
        modified.erase(modified.size() - (SALT2.size() + SALT3.size()));

        return modified;
    }
}

#endif  // BASE64_H

